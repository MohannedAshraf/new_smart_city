import 'package:flutter/material.dart';

Color font_color = const Color.fromRGBO(255, 255, 255, 1);
Color card_color = const Color.fromRGBO(255, 255, 255, 1);
Color card_font_color = const Color.fromARGB(255, 141, 177, 146);
Color theme_color = const Color(0xFF3D6643);
