import 'package:flutter/material.dart';

class AllServices extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('All Services')),
      body: Center(child: Text('All services are displayed here!')),
    );
  }
}