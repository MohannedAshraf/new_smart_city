package com.example.city

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
